
package ContactsDir;
import java.io.*;
import java.util.*;

public class Contact implements Serializable
{
    private String firstName="unknown";
    private String lastName="";
    private String nickname="";
    private ArrayList<String> number=new ArrayList<>();
    private ArrayList<String>  email=new ArrayList<>();
	public String info="";
	public String photourl="";
	
	public Contact(){}
	public Contact(String firstName, String lastName,ArrayList<String> number)
	{
		this.firstName=firstName;
		this.lastName=lastName;
		this.number=number;
	
	}
	public Contact(String firstName,ArrayList<String> number)
	{
		this.firstName=firstName;
		this.number=number;
	
	}
	public Contact(String firstName, String lastName,String nickname,ArrayList<String> number)
	{
		this.firstName=firstName;
		this.lastName=lastName;
		this.nickname=nickname;
		this.number=number;
	
	}
	public Contact(String firstName, String lastName, ArrayList<String>  email, String nickname,ArrayList<String> number)
	{
		this.firstName=firstName;
		this.lastName=lastName;
		this.nickname=nickname;
		this.number=number;
		this.email=email;
	
	}
	public Contact(String firstName, String lastName, ArrayList<String>  email, ArrayList<String> number,String nickname,String info)
	{
		this.firstName=firstName;
		this.lastName=lastName;
		this.nickname=nickname;
		this.number=number;
		this.email=email;
		this.info=info;
	}

    public String toString()
	{
		return "First Name: "+firstName+" | Last Name: "+lastName+" | Phone No. :"+number.get(0);
    }
    public String getFirstname()
	{
		return firstName;
	}
	public void setFirstname(String firstName)
	{
		this.firstName=firstName;
	}
	public String getLastname()
	{
		return lastName;
	}
	public void setLastname(String lastName)
	{
		this.lastName=lastName;
	}
	
	public ArrayList<String> getNumber()
	{
		return number;
	}
	public void setNumber(ArrayList<String> number)
	{
		this.number=number;
	}
	public void setEmail(ArrayList<String>  email)
	{
		this.email=email;
	}
	public ArrayList<String>  getEmail()
	{
		return email;
    }
    public String getNickname()
    {
        return nickname;
    }
    public void setNickname(String nickname)
    {
        this.nickname=nickname;
    }
    public void setInfo(String info)
    {
        this.info=info;
    }
}