package ContactsDir;
import java.util.*;
import java.io.*;
public class Contacts implements Serializable
{
    public ArrayList<Contact> allContacts=new ArrayList<>();
    public Contacts(){
        System.out.println("$"+allContacts);
       
    }
    public Contacts(ArrayList<Contact> contacts){this.allContacts=contacts;}   
}