package ContactsDir;
import java.io.*;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
public class Storage{
    public Contacts contacts;
    public Contacts savedcontacts;
    public Storage()
    {
        savedcontacts=new Contacts();
    }
    public Storage(Contacts contacts)
    {
        this.contacts=contacts;
    }
    public void save()
    {
        try {
            FileOutputStream fileOut =
            new FileOutputStream(getClass().getResource("DB/contacts.ser").getFile());
            ObjectOutputStream out = new ObjectOutputStream(fileOut);
            out.writeObject(contacts);
            out.close();
            fileOut.close();
            System.out.printf("Serialized data is saved in /DB/contactss.ser");
         } catch (IOException i) {
            i.printStackTrace();
         }
   
    }
    public void load()
    {
        try {
            FileInputStream fileIn = new FileInputStream(getClass().getResource("DB/contacts.ser").getFile());
            ObjectInputStream in = new ObjectInputStream(fileIn);
            Object obj=in.readObject();
            if(obj!=null)
                savedcontacts = (Contacts) obj;
            in.close();
            fileIn.close();
   
        } catch (IOException i) {
           
            return;
         } catch (ClassNotFoundException c) {
            System.out.println("Employee class not found");
            c.printStackTrace();
            return;
         }
         
   
    }
    
}