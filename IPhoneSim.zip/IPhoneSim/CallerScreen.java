

import javafx.application.Platform;
import javafx.geometry.Pos;
import javafx.scene.*;
import javafx.scene.layout.*;
import javafx.scene.control.*;
import javafx.scene.image.*;
import javafx.scene.image.ImageView;
import javafx.scene.image.ImageView;
import javafx.scene.image.ImageView;
import javafx.scene.image.ImageView;
import javafx.scene.image.ImageView;
import javafx.scene.image.ImageView;
import javafx.scene.image.ImageView;
import javafx.scene.paint.*;
import java.util.*;
import javafx.scene.*;
import javafx.stage.*;
import javafx.scene.layout.*;
import ContactsDir.*;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import inventory.Effects;

import java.awt.print.Book;
import java.text.*;

public class CallerScreen implements Runnable
{
    private Scene parentScene;
    private Scene baseScene;
    private Scene currentScene;
    private Stage stage,popup;
    private String number;
    private boolean end=false;
    private boolean mute=false;
    private  String defaultaudio= "Normal";
    ImageView[] ivs=new ImageView[7];
    VBox[] boxes=new VBox[7];
    Label[] lbls=new Label[7];

    private Label timeElapsed=new Label();
    public CallerScreen(Stage stage,Scene parentScene,String number)
    {
        this.stage=stage;
    
        this.parentScene=parentScene;
        this.number=number;
       }
      
 
    private void showChoiceDialog() {
 
        String speakers="Speakers";
        String normal="Normal";
        String bluetooth="Bluetooth";
        
 
        ChoiceDialog<String> dialog = new ChoiceDialog<String>(defaultaudio, normal, speakers, bluetooth);
 
        dialog.setTitle("Audio");
        dialog.setHeaderText("");
        dialog.setContentText("");
        ImageView ivs=new ImageView((new Image("image/volume.png")));
        ivs.setFitHeight(40.0);
        ivs.setFitWidth(40.0);
        dialog.setGraphic(ivs);
        
 
        Optional<String> result = dialog.showAndWait();
 
        result.ifPresent(a -> {
         System.out.println(a);
        });
    }
    public Scene callerScene()
    {
       
        StackPane st=new StackPane();
        VBox vb=new VBox();
        ImageView imgv=new ImageView(new Image("image/bg.jpg"));
        imgv.setFitWidth(parentScene.getWidth());
        imgv.setFitHeight(parentScene.getHeight());
        vb.setPrefSize(parentScene.getWidth(), parentScene.getHeight());
        vb.getChildren().add(imgv);
        vb.setEffect(Effects.GAUSSIAN_BLUR());
        st.getChildren().addAll(vb,bp());
        currentScene=new Scene(st,parentScene.getWidth(),parentScene.getHeight(),Color.RED);
          currentScene.getStylesheets().add("css/callers.css");
   return currentScene;

    }
    boolean newcaller=true;
    public String getCallerID()
    {
        PhoneBook pb=new PhoneBook();
      pb.loadPhoneBook();
        for(Contact c:pb.contacts.allContacts)
        {
            for(String s:c.getNumber()){
                newcaller=true;
                if(s.equals(number.trim())){
                    if(c.getNickname().length()>1){
                        return c.getNickname();

                    }
                    else return c.getFirstname()+" "+c.getLastname();
                }

            }
        
        

        }
        return number;
    }
    public BorderPane bp()
    {
        BorderPane bp=new BorderPane();
        VBox vbox=new VBox();
        Label callerID=new Label();
        callerID.setText(getCallerID());
        
        callerID.getStyleClass().add("callerID");
        timeElapsed.getStyleClass().add("tt");
        vbox.setAlignment(Pos.CENTER);
        vbox.getChildren().addAll(callerID,timeElapsed);
        VBox vbox1=new VBox();
        vbox1.setAlignment(Pos.CENTER);
        HBox b1=new HBox();
        HBox b2=new HBox();
       
        vbox1.setSpacing(20);
        Button endCall=new Button();
        Button muteBtn=new Button();
        Button keypadBtn=new Button();
        Button audioBtn=new Button();
        Button addCallBtn=new Button("+");
        Button faceTimeBtn=new Button();
        Button contactsBtn=new Button();
        
        addCallBtn.setDisable(!newcaller);
        muteBtn.setOnAction(e->{

        });
        endCall.getStyleClass().add("endCall");
        muteBtn.getStyleClass().add("muteBtn");
        keypadBtn.getStyleClass().add("keypadBtn");
  
        audioBtn.getStyleClass().add("audioBtn");
        addCallBtn.getStyleClass().add("addCallBtn");
        faceTimeBtn.getStyleClass().add("faceTimeBtn");
        contactsBtn.getStyleClass().add("contactsBtn");

        endCall.setOnAction(e->{
            end=true;
            stage.setScene(parentScene);
        });
        muteBtn.setOnAction(e->{
            if(mute)
            mute=false;
            else mute =true;

            if(mute)
            {
                ivs[0].setImage(new Image("image/mic-off-wh.png"));
                    muteBtn.setGraphic(ivs[0]);
                    lbls[0].setText("unmute");

            }else{
                ivs[0].setImage(new Image("image/mic-on-wh.png"));
                muteBtn.setGraphic(ivs[0]);
                lbls[0].setText("mute");
            }
            
            
        });
        audioBtn.setOnAction(e->{
            showChoiceDialog();
        });
        addCallBtn.setOnAction(e->{
            stage.setScene(new AddCall(stage,currentScene,number).newCallerScene());
        });

        for(int i=0;i<ivs.length;i++)
        {



            ivs[i]=new ImageView();
            boxes[i]=new VBox();
            boxes[i].setAlignment(Pos.CENTER);
            boxes[i].setSpacing(5.0);
            lbls[i]=new Label();
            lbls[i].getStyleClass().add("tt");

            ivs[i].setFitHeight(40.0);
            ivs[i].setFitWidth(40.0);
            switch(i)
            {
                case 0: {
                    ivs[i].setImage(new Image("image/mic-on-wh.png"));
                    muteBtn.setGraphic(ivs[i]);
                    lbls[i].setText("mute");
                    boxes[i].getChildren().addAll(muteBtn,lbls[i]);
                }
                break;
                case 1: {
                    ivs[i].setImage(new Image("image/pad.png"));
                    keypadBtn.setGraphic(ivs[i]);
                    lbls[i].setText("pad");  
                    boxes[i].getChildren().addAll(keypadBtn,lbls[i]);
                }break;
                    case 2: {
                        ivs[i].setImage(new Image("image/volume.png"));
                        audioBtn.setGraphic(ivs[i]);
                        lbls[i].setText("audio");
                        boxes[i].getChildren().addAll(audioBtn,lbls[i]);
                    }break;
                        case 3: {
                          //  ivs[i].setImage(new Image("image/add.png"));
                           // addCallBtn.setGraphic(ivs[i]);
                           lbls[i].setText("add");
                           boxes[i].getChildren().addAll(addCallBtn,lbls[i]);
                        }break;
                            case 4:{

                            ivs[i].setImage(new Image("image/video-call.png"));
                            faceTimeBtn.setGraphic(ivs[i]);
                            lbls[i].setText("facetime");
                            boxes[i].getChildren().addAll(faceTimeBtn,lbls[i]);

                        }break;
                            case 5:{
                                ivs[i].setImage(new Image("image/video-call.png"));
                                contactsBtn.setGraphic(ivs[i]);
                                lbls[i].setText("contacts");
                                boxes[i].getChildren().addAll(contactsBtn,lbls[i]);
    
                            }break;
                            case 6:{
                                ivs[i].setImage(new Image("image/end-call-button.png"));  contactsBtn.setGraphic(ivs[i]);
                                endCall.setGraphic(ivs[i]);
                                lbls[i].setText("end");
                            boxes[i].getChildren().addAll(endCall,lbls[i]);

                            }break;

            }
         

        }
      
        
                              
    

        b1.getChildren().addAll(boxes[0],boxes[1],boxes[2]);
        b2.getChildren().addAll(boxes[3],boxes[4],boxes[5]);
        b1.setSpacing(15);
        b2.setSpacing(15);
        b1.setAlignment(Pos.CENTER);
        b2.setAlignment(Pos.CENTER);
    
        HBox b3=new HBox();
        b3.setAlignment(Pos.CENTER);
        b3.getChildren().add(boxes[6]);
        b3.setSpacing(15);
       // bp.setTop(vbox);
        bp.setCenter(vbox1);
       // bp.setBottom(b3);
       vbox1.getChildren().addAll(vbox,b1,b2,b3);

        return bp;

    }
    long millis=0;
    @Override
    public void run()
    {
        
        while(!end)
        {
            Platform.runLater(new Runnable(){
            
                @Override
                public void run() {
                      if(millis>360000){
                timeElapsed.setText(new SimpleDateFormat("h:mm:ss").format(millis));
            }else 
            timeElapsed.setText(new SimpleDateFormat("mm:ss").format(millis));
           
            }
        });
           millis+=1000;
        try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                //TODO: handle exception
            }
        }

    }
}