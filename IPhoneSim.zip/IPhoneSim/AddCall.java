

import javafx.application.Platform;
import javafx.geometry.*;
import javafx.scene.*;
import javafx.scene.layout.*;
import javafx.scene.control.*;
import javafx.scene.control.ScrollPane.ScrollBarPolicy;
import javafx.scene.image.*;
import javafx.scene.image.ImageView;
import javafx.scene.image.ImageView;
import javafx.scene.image.ImageView;
import javafx.scene.image.ImageView;
import javafx.scene.image.ImageView;
import javafx.scene.image.ImageView;
import javafx.scene.image.ImageView;
import javafx.scene.paint.*;
import java.util.*;
import javafx.scene.*;
import javafx.stage.*;
import javafx.scene.layout.*;
import ContactsDir.*;
import inventory.Effects;

import java.awt.print.Book;
import java.text.*;

public class AddCall
{
    private Scene parentScene;
    private Scene baseScene;
    private Scene currentScene;
    private Stage stage;
    private String number;
    private Contact contact=null,old_contact;
    private boolean edit=false;

    ImageView[] ivs=new ImageView[7];
    VBox[] boxes=new VBox[7];
    Label[] lbls=new Label[7];

    public Contact getContact()
    {
        return old_contact;
    }
    private Label timeElapsed=new Label();
    public AddCall(Stage stage,Scene parentScene,String number)
    {
        this.stage=stage;
    
        this.parentScene=parentScene;
        this.number=number;
        isNew();
    }
    public AddCall(Stage stage,Scene parentScene,Contact contact)
    {
        this.stage=stage;
    
        this.parentScene=parentScene;
        this.contact=contact;
       
    }
    public AddCall(Stage stage,Scene parentScene,Contact contact,Contact old_contact,boolean edit)
    {
        this.stage=stage;
        this.edit=edit;
    
        this.parentScene=parentScene;
        this.contact=contact;
  
        this.old_contact=old_contact;
       
    }
    public boolean isNew()
    {
      
            PhoneBook pb=new PhoneBook();
          pb.loadPhoneBook();
            for(Contact c:pb.contacts.allContacts)
            {
                for(String s:c.getNumber()){
                 if (s==number)
                   return true;
                      
    
                }
            
            
    
            }
            return false;
        
    }
 
    public Scene newCallerScene()
    {
       
       
        currentScene=new Scene(bp(),parentScene.getWidth(),parentScene.getHeight(),Color.RED);
          currentScene.getStylesheets().add("css/newId.css");
   return currentScene;

    }
   VBox phoneBx=new VBox();
   VBox emailBx=new VBox();
   
     ArrayList<TextField>phones=new ArrayList<>();
    ArrayList<TextField>emails=new ArrayList<>();
    TextArea notes=new TextArea();
    TextField nameField=new TextField();
    TextField lastField=new TextField();
    TextField nicknameField=new TextField();
    TextField phtf=new TextField();
    TextField phtf1=new TextField();
 
    public BorderPane bp()
    {
        BorderPane bp=new BorderPane();
        VBox vbox=new VBox();
       HBox appbar=new HBox();
       Button cancel=new Button("Cancel");
       cancel.getStyleClass().add("cancel");

       Button done=new Button("Done");
       done.getStyleClass().add("done");
       Label lb=new Label("New Contact");
       appbar.getChildren().addAll(cancel,lb,done);
       appbar.getStyleClass().add("appbar");
       lb.getStyleClass().add("nc");

       cancel.setOnAction(e->{
           stage.setScene(parentScene);
       });
       done.setOnAction(e->{
           PhoneBook phonebook=new PhoneBook();
           ArrayList<String>mails=new ArrayList<>();
           mails.add(phtf.getText().isEmpty()?"none":phtf1.getText().trim());
           for(TextField t:emails){
            mails.add(t.getText().trim());
           }
           ArrayList<String>numbers=new ArrayList<>();
           numbers.add(phtf.getText().isEmpty()?"none":phtf.getText().trim());

           for(TextField t:phones){
            numbers.add(t.getText().trim());
           }
           Contact contact=new Contact(nameField.getText().trim(), lastField.getText().trim() , mails,numbers,nicknameField.getText().trim(),notes.getText().trim());
           old_contact=contact;
            if(edit)
           phonebook.editContact(contact,this.contact);
           else
           phonebook.savetoPhoneBook(contact);
          
           stage.setScene(parentScene);

       });

       HBox hbox=new HBox();
       appbar.setSpacing(100);
       appbar.setAlignment(Pos.CENTER);
       VBox vbox1=new VBox();
       vbox1.setAlignment(Pos.CENTER);
       vbox1.setPadding(new Insets(5));
       vbox1.getStyleClass().add("av");
       Button avatar=new Button();
       avatar.getStyleClass().add("avatar");

       Button addPhoto=new Button("edit");
       addPhoto.getStyleClass().add("text");

       VBox vbox2=new VBox();
    
        nameField.setPromptText("First name");
        nameField.getStyleClass().add("textfield");
        nameField.setPrefWidth(Integer.MAX_VALUE);
        
        lastField.setPromptText("Last name");
        lastField.getStyleClass().add("textfield");
        lastField.setPrefWidth(Integer.MAX_VALUE);


        
        nicknameField.setPromptText("Nickname");
        nicknameField.getStyleClass().add("textfield");
        nicknameField.setPrefWidth(Integer.MAX_VALUE);

       

        vbox2.getChildren().addAll(nameField,new Separator(),lastField,new Separator(),nicknameField,new Separator());
       vbox2.setPadding(new Insets(12.0));
       vbox2.setSpacing(2.5);
        vbox1.getChildren().addAll(avatar,addPhoto);
        hbox.getChildren().addAll(vbox1,vbox2);
        
        Button addPhBtn=new Button("+");
        addPhBtn.getStyleClass().add("ap");
        Button remPhButton=new Button("-");remPhButton.setDisable(true);
        
        Button addPhBtn1=new Button("+");
        addPhBtn1.getStyleClass().add("ap");
        Button remPhButton1=new Button("-");
        remPhButton1.setDisable(true);
       
        remPhButton.setOnAction(e->{
            if(phones.size()<=1)
            remPhButton.setDisable(true);
             phones.remove(phones.remove(phones.size()-1));
            Platform.runLater(new Runnable(){
                @Override
                public void run(){
                     phoneBx.getChildren().clear();
            phoneBx.getChildren().addAll(phones);
                }
                 
    
            });
              });
        addPhBtn.setOnAction(e->{
            TextField tf=new TextField();
            remPhButton.setDisable(false);
            tf.setPromptText("Enter Phone number");
            phones.add(tf);
            Platform.runLater(new Runnable(){
                @Override
                public void run(){
                     phoneBx.getChildren().clear();
            phoneBx.getChildren().addAll(phones);
                }
                 
    
            });
              });

              remPhButton1.setOnAction(e->{
                if(emails.size()<=1)
                remPhButton1.setDisable(true);
                 emails.remove(phones.remove(emails.size()-1));
                Platform.runLater(new Runnable(){
                    @Override
                    public void run(){
                         emailBx.getChildren().clear();
                emailBx.getChildren().addAll(emails);
                    }
                     
        
                });
                  });
            addPhBtn1.setOnAction(e->{
                TextField tf=new TextField();
                remPhButton1.setDisable(false);
                tf.setPromptText("Enter Email");
                emails.add(tf);
                Platform.runLater(new Runnable(){
                    @Override
                    public void run(){
                         emailBx.getChildren().clear();
                emailBx.getChildren().addAll(emails);
                    }
                     
        
                });
                  });
  HBox addBox=new HBox();
        addBox.getChildren().addAll(addPhBtn,remPhButton);
       
        phtf.setPromptText("Enter Phone number");
        phtf.setText(number);

        HBox addBox1=new HBox();
        addBox1.getChildren().addAll(addPhBtn1,remPhButton1);
      
        phtf1.setPromptText("Enter Email");
      
       
        phoneBx.getChildren().addAll(phones);
        VBox vb=new VBox();
        notes.setPromptText("notes");
        vb.getChildren().addAll(new Label("Phone"),new Separator(),phtf,new Separator(),phoneBx,new Separator(),addBox,new Separator(),new Label("Email"),new Separator(),phtf1,new Separator(),emailBx,new Separator(),addBox1,notes);



        hbox.setPadding(new Insets(10.0));
        hbox.getStyleClass().add("name");
           ScrollPane scrollPane=new ScrollPane();
           vb.setPrefHeight(parentScene.getHeight());
      scrollPane.setContent(vb);
      scrollPane.setHbarPolicy(ScrollBarPolicy.AS_NEEDED);
      scrollPane.setVbarPolicy(ScrollBarPolicy.AS_NEEDED);
      vbox.getChildren().addAll(appbar,hbox,scrollPane);
  
      bp.setCenter(vbox);
       // bp.setBottom(b3);

       if(contact!=null){
        nameField.setText(contact.getFirstname());
        if(!contact.getLastname().isEmpty())
        lastField.setText(contact.getLastname());
        if(!contact.getNickname().isEmpty())
        nicknameField.setText(contact.getNickname());
        phtf.setText(contact.getNumber().get(0));
        if(contact.getEmail().size()>=1)
        {
            phtf1.setText(contact.getEmail().get(0));

            for(String s:contact.getEmail()){
                TextField tf=new TextField();
                tf.setText(s);
                emails.add(tf);
            }
        }

        for(String s:contact.getNumber()){
            TextField tf=new TextField();
            tf.setText(s);
            phones.add(tf);
        }

        Platform.runLater(new Runnable(){
            @Override
            public void run(){
                 emailBx.getChildren().clear();
                emailBx.getChildren().addAll(emails);
                phoneBx.getChildren().clear();
                phoneBx.getChildren().addAll(phones);
            }
             

        });

        
    }
      

        return bp;

    }
  
}