import ContactsDir.*;
public class PhoneBook
{
    public Contacts contacts=new Contacts();
    public PhoneBook()
    {
        
    }
    public void loadPhoneBook()
    {
        Storage storage=new Storage();
        storage.load();
        contacts=storage.savedcontacts;
        

    }
    public boolean savetoPhoneBook(Contact newContact)
    {
         Storage storage=new Storage(contacts);
        storage.load();
        if(storage.savedcontacts!=null){
            contacts.allContacts=storage.savedcontacts.allContacts;
        }
        int i=1;
        for(Contact c:contacts.allContacts)
        {
          
            if(c.getFirstname().trim().equalsIgnoreCase(newContact.getFirstname()))
            {
               
                if(!c.getNumber().contains(newContact.getNumber().get(0)))
                {
                    c.getNumber().add(newContact.getNumber().get(0));
                    return true;
                }
                else{
                    newContact.setFirstname(newContact.getFirstname()+i++);
                    return true;

                }
            }
        
        }
       
       
        if(storage.savedcontacts!=null){
        contacts.allContacts=storage.savedcontacts.allContacts;
        contacts.allContacts.add(newContact);
        
        storage.save();
        return true;}
        else{storage.savedcontacts=new Contacts();
        contacts.allContacts=storage.savedcontacts.allContacts;
        contacts.allContacts.add(newContact);
        
        storage.save();}

        return false;

    
    }
    public boolean editContact(Contact newContact,Contact old)
    {
        Storage storage=new Storage(contacts);
        storage.load();
        int i=-1;
        for(Contact c:storage.savedcontacts.allContacts)
        {
            if(c.getFirstname().trim().equals(old.getFirstname().trim()))
            {
                ++i;
                break;
            }
            else i++;
        }
        System.out.println("OLD: "+old.getFirstname()+"\nNEW: "+newContact.getFirstname()+"\n"+i);
        storage.savedcontacts.allContacts.set(i,newContact);
        contacts.allContacts=storage.savedcontacts.allContacts;
        for(Contact c:storage.contacts.allContacts)
        {
           System.out.println(c.getFirstname());
        }
        storage.save();
        return true;
    }

}