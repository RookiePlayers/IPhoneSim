import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.*;
import javafx.scene.input.MouseEvent;
import javafx.geometry.*;
import javafx.geometry.Side;
import javafx.scene.Group;
import javafx.scene.*;
import javafx.scene.image.*;
import javafx.scene.control.*;
import javafx.scene.control.ScrollPane.*;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.layout.*;
import javafx.scene.layout.HBox;
import javafx.scene.paint.*;
import javafx.stage.Stage;
import java.io.*;
import java.util.*;
import javafx.scene.shape.*;
import javafx.scene.text.*;
import javafx.scene.shape.*;
import javafx.scene.effect.*;
import javafx.scene.paint.*;
import javafx.scene.text.*;
import javafx.animation.*;
import java.time.*;
import javafx.util.Duration;
import javafx.scene.media.AudioClip;
import ContactsDir.*;
public class ProfileSpace{
    private Stage stage;
    private Scene parentscene,currentscene;
    private Contact contact;
    private AddCall editingScene;
    public ProfileSpace(Stage stage,Scene parentScene,Contact contact)
    {
        this.stage=stage;
        this.parentscene=parentScene;
        this.contact=contact;

    }
    public void reload()
    {
      this.contact=editingScene.getContact();
      System.out.println(contact.getFirstname());
        Platform.runLater(new Runnable(){
            @Override
            public void run(){
                currentscene=new Scene(bp(),parentscene.getWidth(),parentscene.getHeight());
                currentscene.getStylesheets().add("css/contact.css");
            }
        });
    }
    public Scene profileScene()
    {
        currentscene=new Scene(bp(),parentscene.getWidth(),parentscene.getHeight());
        stage.setScene(currentscene);
        currentscene.getStylesheets().add("css/contact.css");
        return currentscene;
    }
    public BorderPane bp()
    {
        
        VBox space=iconsBox();
          VBox field=infoBox();
        
       field.setAlignment(Pos.CENTER);
        field.setSpacing(10); 
         space.setAlignment(Pos.CENTER);
        space.setSpacing(10); 
        BorderPane borderPane=new BorderPane();
        borderPane.prefHeightProperty().bind(parentscene.heightProperty());
        borderPane.prefWidthProperty().bind(parentscene.widthProperty());
        //borderPane.setAlignment(field,Pos.CENTER);
        borderPane.setTop(space);
        
       borderPane.setCenter(field);
       return borderPane;
    }
    public HBox cancelAndDone()
    {
        VBox box=new VBox();
        HBox hbox1=new HBox();
        Hyperlink cancel=new Hyperlink("Cancel");
        cancel.setVisited(false);
        Hyperlink done=new Hyperlink("Done");
        hbox1.getChildren().addAll(cancel,done);
        cancel.setTranslateX(0);
        done.setTranslateX(200);
        return hbox1;

    }
    public Label setIcon()
    {
        Label icon;
        DropShadow ds = new DropShadow();
        ds.setOffsetY(3.0);
        ds.setOffsetX(3.0);
        ds.setColor(Color.GRAY);
           
        if(contact.getLastname().isEmpty())
        {
           icon=new Label(contact.getFirstname().charAt(0)+"");
             //   icon.getText();
        }
        else{
                icon=new Label(contact.getFirstname().charAt(0)+""+contact.getLastname().charAt(0));
        }
       
        icon.setTextFill(Color.WHITE);
        icon.setFont(Font.font("Cambria", FontWeight.BOLD,32));
        icon.setEffect(ds);
      
        icon.setTextFill(Color.WHITE);
        icon.setFont(Font.font("Cambria", FontWeight.BOLD,32));
        icon.setEffect(ds);

         return icon;

   }
   public Label setIconText()
   {
       Label iconText=new Label();
        
       iconText=new Label(contact.getFirstname()+" "+contact.getLastname());
       iconText.setTextFill(Color.BLACK);
       iconText.setFont(Font.font("Cambria", FontWeight.BOLD,20));
      // iconText.setEffect(ds);
       return iconText;
   }
   
 public VBox iconsBox()
 {
         
                DropShadow ds = new DropShadow();
                 ds.setOffsetY(3.0);
                 ds.setOffsetX(3.0);
                 ds.setColor(Color.GRAY);
                  Image img[]=new Image[4];
                     ImageView iV[]=new ImageView[4];
                    
                 VBox vbox2=new VBox();
                  // user="Lizzy Dimples";String no="0899654645";

                 
                  String[]icn=new String[]{"c.png","md.png","p.png","v.png"};
                 Button back=new Button("",new ImageView(new Image("image/back.png")));
                 back.getStyleClass().add("back");
                 back.setOnAction(e->stage.setScene(parentscene));
                  String[]str=new String[]{"message","mail","call","video"};
                   Label lbl1[]=new Label[4];
                 HBox hbox=new HBox();
                 Label lbl[]=new Label[4];
                 Button[]btns=new Button[4];
                 VBox vbox1[]=new VBox[4];
                 Hyperlink edit=new Hyperlink("Edit");
                  Hyperlink contacts=new Hyperlink("Contacts");
                 edit.setVisited(false);

                 edit.setOnAction(e->{
                   
                     editingScene=new AddCall(stage,currentscene,contact,contact,true);
                       stage.setScene(editingScene.newCallerScene());
                       
                    });
                 contacts.setVisited(false);
              //   contacts.setOnAction(e->stage.setScene(scene));
                 for (int i=0;i<btns.length ;i++ ) 
                 {
                     img[i]=new Image("image/"+icn[i]);
                     iV[i]=new ImageView(img[i]);
                       btns[i]=new Button("",iV[i]);
                     

                              btns[i].getStyleClass().add("Profilebtns");
                            

                 }

                   btns[0].setOnMouseEntered(e-> iV[0].setEffect(ds)) ;
                btns[0].setOnMouseExited(e->iV[0].setEffect(null));
                  btns[1].setOnMouseEntered(e-> iV[1].setEffect(ds)) ;
                btns[1].setOnMouseExited(e->iV[1].setEffect(null));
                  btns[3].setOnMouseEntered(e-> iV[3].setEffect(ds)) ;
                btns[3].setOnMouseExited(e->iV[3].setEffect(null));
                  btns[2].setOnMouseEntered(e-> iV[2].setEffect(ds)) ;
                btns[2].setOnMouseExited(e->iV[2].setEffect(null));
                btns[2].setOnAction(e->stage.setScene(new KeyPadScene(stage, currentscene,contact.getNumber().get(0)).keyPad()));
                 back.setOnMouseEntered(e-> back.setEffect(ds)) ;
                back.setOnMouseExited(e->back.setEffect(null));
                 for(int i=0;i<btns.length;i++)
                   { 
                     vbox1[i]=new VBox();
                      Hyperlink link = new Hyperlink(str[i]);
                     link.setVisited(false);
                    // user=pb.get(0).get(i)+" "+pb.get(1).get(i);
                   //  link.setOnAction(e -> stage.setScene(profileSpace()));
                     link.getStyleClass().add("icnlbl");
                                
                                  vbox1[i].getChildren().addAll(btns[i],link);
                                  vbox1[i].setAlignment(Pos.CENTER);
                                

                 }
                 hbox.getChildren().addAll(vbox1[0],vbox1[1],vbox1[2],vbox1[3]);
                   hbox.setAlignment(Pos.CENTER);
                 hbox.setSpacing(20);

                Circle cl=createCircle();
                 Label text=setIcon();
                 Label iT=setIconText();
                 Label nickname=new Label(contact.getNickname().isEmpty()?"":contact.getNickname());
                 text.getStyleClass().add("iconText");
                Group group=new Group(cl,text);
                 StackPane stack=new StackPane();
                 stack.getChildren().addAll(group,text);
                 HBox upper=new HBox();
                 Button refresh=new Button("Refresh");
                 refresh.getStyleClass().add("refresh");refresh.setOnAction(e->{
                     reload();
                 });
                upper.getChildren().addAll(back,contacts,edit,refresh);
                upper.setSpacing(50);
                upper.setAlignment(Pos.CENTER);
                back.setTranslateX(-10);

                 upper.setAlignment(Pos.TOP_LEFT);
                 contacts.setTranslateX(-25);
                 contacts.setTranslateY(10);
                 contacts.setFont(Font.font("Cambria",18));
                  edit.setFont(Font.font("Cambria",18));
                 edit.setTranslateX(parentscene.getWidth()*0.02);
                  edit.setTranslateY(10);
                  refresh.setTranslateX(parentscene.getWidth()*0.01);
                  refresh.setTranslateY(10);
                // upper.setSpacing(200);
                 VBox iconSetup=new VBox();
                 stack.setTranslateY(20);
                 iT.setTranslateY(0);
                 iT.setTextFill(Color.TRANSPARENT);
                 iconSetup.getChildren().addAll(stack,iT);
                iconSetup.setSpacing(5);
                 iconSetup.setAlignment(Pos.CENTER);
                 stack.setOnMouseEntered(new EventHandler<MouseEvent>() 
                 {
                     @Override 
                     public void handle(MouseEvent e) {
                         TranslateTransition transition=new TranslateTransition();
                         transition.setDuration(Duration.millis(1200));
                         transition.setNode(stack);
                         transition.setToY(0);
                         transition.setAutoReverse(true);
                         transition.play();

                         
                         
                        // label3.setScaleY(1.5);
                 }
              });
                stack.setOnMouseExited(new EventHandler<MouseEvent>() 
                {
                     @Override 
                     public void handle(MouseEvent e) 
                     {
                           stack.setTranslateY(20);
                           iT.setTranslateY(0);
                           iT.setTextFill(Color.BLACK);
                       
                     }
                 });


                 vbox2.getChildren().addAll(upper,iconSetup,hbox);
                 vbox2.setSpacing(5);
                 vbox2.getStyleClass().add("profile_box");
                 return vbox2;
 }
 public VBox infoBox()
 {
    for (String var : contact.getNumber()) {
        System.out.println("$"+var);
    }

     VBox m=new VBox();
     VBox m2=new VBox();
     ScrollPane spane=new ScrollPane();
     spane.setVbarPolicy(ScrollBarPolicy.ALWAYS);
       spane.setHbarPolicy(ScrollBarPolicy.AS_NEEDED);
    
      
     Separator sp[]=new Separator[8];
     m.getStyleClass().add("infoBox");
    
         for(int i=0;i<sp.length;i++)
        { sp[i]=new Separator();
                    sp[i].setMaxWidth(10000);

         }
         VBox vb=new VBox();
         Label lbl=new Label("mobile:");
         ArrayList<Hyperlink>nums=new ArrayList<>();
         for(int i=0;i<contact.getNumber().size();i++)
         {
            nums.add(new Hyperlink()); 
            nums.get(i).setText(contact.getNumber().get(i));
              nums.get(i).setVisited(false);nums.get(i).setFont(Font.font(20));
              
         }
         for(Hyperlink link:nums)
         {
             link.setOnAction(e->{
                 stage.setScene(new KeyPadScene(stage,currentscene,link.getText()).keyPad());
             });
         }
         VBox bx=new  VBox();
         bx.getChildren().addAll(nums);
         //new Hyperlink(contact.getNumber().get(0));
        
         
         vb.getChildren().add(lbl);
         vb.getChildren().add(bx);
         vb.getChildren().add(2,sp[0]);

         Hyperlink link[]=new Hyperlink[5];
         link[0]=new Hyperlink("Send Message");
           link[1]=new Hyperlink("Share Contact");
             link[2]=new Hyperlink("Add to Favourites");
               link[3]=new Hyperlink("Share My Location");
                 link[4]=new Hyperlink("Block This Caller");
                 

          VBox vb1=new VBox();
         Label lb2=new Label("instant message:");
         Label lb3=new Label(contact.getNumber().get(0));

         TextField tf=new TextField();
         tf.setPromptText("Note:");
         tf.setText(this.contact.info);

         lb3.setTextFill(Color.GRAY);
         vb1.getChildren().addAll(lb2,lb3);
         vb1.getChildren().add(2,sp[1]);vb1.setSpacing(10);

           VBox vb2=new VBox();
            vb2.getChildren().addAll(tf);vb2.setSpacing(10);
         vb2.getChildren().add(1,sp[2]);

          VBox vb3=new VBox();
            vb3.getChildren().addAll(link[0]);vb3.setSpacing(10);
         vb3.getChildren().add(1,sp[3]);

          VBox vb4=new VBox();
            vb4.getChildren().addAll(link[1]);vb4.setSpacing(10);
         vb4.getChildren().add(1,sp[7]);

          VBox vb5=new VBox();
            vb5.getChildren().addAll(link[2]);vb5.setSpacing(10);
         vb5.getChildren().add(1,sp[4]);

          VBox vb6=new VBox();
            vb6.getChildren().addAll(link[3]);vb6.setSpacing(10);
         vb6.getChildren().add(1,sp[5]);

             VBox vb7=new VBox();
            vb7.getChildren().addAll(link[4]);vb7.setSpacing(10);
         vb7.getChildren().add(1,sp[6]);




         m2.getChildren().addAll(vb,vb1,vb2,vb3,vb4,vb5,vb6,vb7);
          m2.setAlignment(Pos.TOP_LEFT); spane.getStyleClass().add("spane");
           spane.setContent(m2);

           m.getChildren().addAll(spane);

         return m;

     

 }
   public Circle createCircle() 
   {
         Circle circle = new Circle(50);
         DropShadow ds = new DropShadow();
         ds.setOffsetY(3.0);
         ds.setOffsetX(3.0);
         ds.setColor(Color.GRAY);
        //circle.setStroke(Color.BLUE);
         circle.setStrokeWidth(5);
         circle.setStrokeType(StrokeType.INSIDE);
         //   circle.setID("circ");
           circle.setFill(Paint.valueOf("#b3b3b3"));
         circle.relocate(0, 0);
         circle.setEffect(ds);
         
         return circle;
 }
 public Text createText(String t)
 {
     Text text=new Text(t); 
     text.setFont(new Font(30));
    // text.getStyleClass().add("iconText");
     text.setBoundsType(TextBoundsType.VISUAL); 

     return text;
 }
 private void centerText(Text text) 
 {
     double W = text.getBoundsInLocal().getWidth();
     double H = text.getBoundsInLocal().getHeight();
     text.relocate(50 - W / 2, 50 - H / 2);

 }



}