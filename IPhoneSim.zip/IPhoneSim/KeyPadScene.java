
import javafx.animation.*;
import javafx.application.*;
import javafx.stage.Stage;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.*;
import javafx.scene.input.MouseEvent;
import javafx.geometry.*;
import javafx.geometry.Side;
import javafx.scene.Group;
import javafx.scene.*;
import javafx.scene.image.*;
import javafx.scene.control.*;
import javafx.scene.control.ScrollPane.*;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.layout.*;
import javafx.scene.layout.HBox;
import javafx.scene.paint.*;
import javafx.stage.Stage;
import java.io.*;
import java.util.*;
import javafx.scene.shape.*;
import javafx.scene.text.*;
import javafx.scene.shape.*;
import javafx.scene.effect.*;
import javafx.scene.paint.*;
import javafx.scene.text.*;
import javafx.animation.*;
import java.time.*;
import javafx.util.Duration;
import javafx.scene.media.AudioClip;
public class KeyPadScene
{
    private Button b=null;
    TextField space;
    String keypadnums="";
    private Stage stage;
    private Scene parentScene,sc;
  private ArrayList<String>dialed=new ArrayList<String>();

    private Button buttn[]=new Button[10];
    private String number="";
    public KeyPadScene(Stage stage,Scene parentScene)
    {
        this.stage=stage;
        this.parentScene=parentScene;

    }
    public KeyPadScene(Stage stage,Scene parentScene,String number)
    {
        this.stage=stage;
        this.parentScene=parentScene;
        this.number=number;
        keypadnums=number;

    }
    public VBox numPad()
{
      DropShadow ds = new DropShadow();
        ds.setOffsetY(3.0);
        ds.setOffsetX(3.0);
        ds.setColor(Color.GRAY);
    VBox elements=new VBox();
  
    Button btn[]=new Button[6];
    btn[0]=new Button("*");
    btn[0].getStyleClass().add("btn");
   btn[0].setOnAction(new EventHandler<ActionEvent>()
          {
            @Override
            public void handle(ActionEvent e)
            {
                
                b=(Button)e.getSource();
                //System.out.println(b.getText());
               
              dialPad(b.getText());
            }
          }
          );
          
    btn[1]=new Button("0");
    btn[1].getStyleClass().add("btn");
   btn[1].setOnAction(new EventHandler<ActionEvent>()
          {
            @Override
            public void handle(ActionEvent e)
            {
                
                b=(Button)e.getSource();
                //System.out.println(b.getText());
               
              dialPad(b.getText());
            }
          }
          );
          
    btn[2]=new Button("#");
    btn[2].getStyleClass().add("btn");
    btn[2].setOnAction(new EventHandler<ActionEvent>()
          {
            @Override
            public void handle(ActionEvent e)
            {
                
                b=(Button)e.getSource();
                //System.out.println(b.getText());
               
              dialPad(b.getText());
            }
          }
          );
          btn[4]=new Button("DEL");
          btn[4].getStyleClass().add("caller");
          btn[4].setOnAction(e->
          {
             if(keypadnums.length()>=1) keypadnums=keypadnums.substring(0,keypadnums.length()-1);
              space.setText(keypadnums);
          });
       
          btn[5]=new Button("CA");
          btn[5].getStyleClass().add("caller");
          btn[5].setOnAction(e->{
              keypadnums="";
              space.setText(keypadnums);
          });
       

    Image img=new Image("image/dialer_icon.png");
            ImageView iV=new ImageView(img);
            btn[3]=new Button("",iV);
            btn[3].getStyleClass().add("caller");
            iV.setEffect(ds);
            btn[3].setOnAction(new EventHandler<ActionEvent>()
          {
            @Override
            public void handle(ActionEvent e)
            {
              if(keypadnums.length()>=5)  
              {
                CallerScreen call=new CallerScreen(stage, sc, keypadnums);
                Thread t=new Thread(call);
                t.start();
                stage.setScene(call.callerScene());
              }
             
            }
          }
          );
          
             //btn[3].setOnAction(new dialPad());
    for (int i=1;i<buttn.length;i++ ) 
    {
        buttn[i]=new Button(i+""); 
          buttn[i].getStyleClass().add("btn");
          buttn[i].setOnAction(new EventHandler<ActionEvent>()
          {
            @Override
            public void handle(ActionEvent e)
            {
                
                b=(Button)e.getSource();
                //System.out.println(b.getText());
               
              dialPad(b.getText());
            }
          }
          );
          
         
          
        
    }
    HBox set1=new HBox();
    set1.getChildren().addAll(buttn[1],buttn[2],buttn[3]);
    set1.setSpacing(15);
    HBox set2=new HBox();
    set2.getChildren().addAll(buttn[4],buttn[5],buttn[6]);
      set2.setSpacing(15);
    HBox set3=new HBox();
    set3.getChildren().addAll(buttn[7],buttn[8],buttn[9]);
      set3.setSpacing(15);
    HBox set4=new HBox();
    set4.getChildren().addAll(btn[0],btn[1],btn[2]);
      set4.setSpacing(15);
      HBox set5=new HBox();
      set5.getChildren().addAll(btn[4],btn[3],btn[5]);
      set5.setSpacing(15);

    elements.getChildren().addAll(set1,set2,set3,set4,set5);
    elements.setSpacing(15);
    set1.setAlignment(Pos.CENTER);
    set2.setAlignment(Pos.CENTER);
    set3.setAlignment(Pos.CENTER);
    set4.setAlignment(Pos.CENTER);
    set5.setAlignment(Pos.CENTER);
    return elements;
}
    public Scene keyPad()
    {
        
        Group root=new Group();
         sc=new Scene(root,parentScene.getWidth(),parentScene.getHeight(),parentScene.getFill());
        sc.getStylesheets().add("css/contact.css");
        VBox field=new VBox();
        space=new TextField();
        space.setPromptText("Enter phone number...");
        space.getStyleClass().add("textfield");
        space.setEditable(false);
        space.setText(number);
        Separator sep=new Separator();
        field.getChildren().addAll(space,sep,numPad());
       field.setAlignment(Pos.CENTER);
        field.setSpacing(10); 
        BorderPane borderPane=new BorderPane();
        borderPane.prefHeightProperty().bind(sc.heightProperty());
        borderPane.prefWidthProperty().bind(sc.widthProperty());
        //borderPane.setAlignment(field,Pos.CENTER);
     Button backBtn=new Button("<<");
     HBox hbox=new HBox();
     hbox.setAlignment(Pos.CENTER_RIGHT);
     hbox.getChildren().add(backBtn);
     backBtn.getStyleClass().add("back");
     backBtn.setOnAction(e->stage.setScene(parentScene));
  
        borderPane.setTop(backBtn);
       borderPane.setBottom(field);

        root.getChildren().addAll(borderPane);

        return sc;

    }
    private void dialPad(String n)
        {
           
                if(keypadnums.length()<=20)
                keypadnums+=n;
                space.setText(keypadnums);

            
        }

}