
import javafx.animation.*;
import javafx.application.*;
import javafx.stage.Stage;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.*;
import javafx.scene.input.MouseEvent;
import javafx.geometry.*;
import javafx.geometry.Side;
import javafx.scene.Group;
import javafx.scene.*;
import javafx.scene.image.*;
import javafx.scene.control.*;
import javafx.scene.control.ScrollPane.*;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.layout.*;
import javafx.scene.paint.*;
import javafx.stage.Stage;
import java.io.*;
import java.util.*;
import javafx.scene.shape.*;
import javafx.scene.text.*;
import javafx.scene.shape.*;
import javafx.scene.effect.*;
import javafx.scene.paint.*;
import javafx.scene.text.*;
import javafx.animation.*;
import java.time.*;
import javafx.util.Duration;
import javafx.scene.media.AudioClip;
import ContactsDir.*;

public class Main extends Application
{
    private Scene main_scene;
    private Stage stage;
    PhoneBook phonebook=new PhoneBook();
    @Override
    public void start(Stage stage)
    {
        this.stage=new Stage();
        load(stage);
        
       

    }
    public void load(Stage stage)
    {
        stage=this.stage;
        stage.setTitle("IPHONE");
        Group root = new Group();
      
       main_scene = new Scene(root, 500, 730, Color.WHITE);
       TabPane tabPane = new TabPane();
       ScrollPane sp=new ScrollPane();
       BorderPane borderPane = new BorderPane();
       Tab tab = new Tab();
       tab.setText("Contacts");
       HBox hbox = new HBox();
       hbox.getChildren().addAll(createPage());
       hbox.setAlignment(Pos.TOP_LEFT);
       sp.setContent(hbox);
       sp.setVbarPolicy(ScrollBarPolicy.AS_NEEDED);
       sp.setHbarPolicy(ScrollBarPolicy.AS_NEEDED);
         tab.setContent(sp);
         tabPane.getTabs().addAll(tab);

         Tab tab1 = new Tab();
         tab1.setText("Recents");
         HBox hbox1 = new HBox();
         hbox1.getChildren().add(new Label("Loading Recents..."));
         hbox1.setAlignment(Pos.CENTER);
         tab1.setContent(hbox1);
         tabPane.getTabs().add(tab1);

          Tab tab2 = new Tab();
         tab2.setText("Favourites");
         HBox hbox2 = new HBox();
         hbox2.getChildren().add(new Label("No Favourites"));
         hbox2.setAlignment(Pos.CENTER);
         tab2.setContent(hbox2);
         tabPane.getTabs().add(tab2);

          // bind to take available space
        borderPane.prefHeightProperty().bind(main_scene.heightProperty());
        borderPane.prefWidthProperty().bind(main_scene.widthProperty());
        
        borderPane.setCenter(tabPane);
        HBox btns=new HBox();
        btns=createButtons(3);
        btns.setAlignment(Pos.BOTTOM_CENTER);
        borderPane.setBottom(btns);
        root.getChildren().addAll(borderPane);

        stage.setScene(main_scene);
        stage.setResizable(false);
        stage.show();
     
    }
    public ArrayList<Contact> orderd()
    {
        ArrayList<Contact>list=new ArrayList<>();
        list=phonebook.contacts.allContacts;
        for(int i=0;i<list.size();i++)
        {
            for(int j=0;j<list.size();j++)
            {
                Contact tempC=new Contact();
                if(list.get(i).getFirstname().compareTo(list.get(j).getFirstname())<0){
                    tempC=list.get(i);
                    list.set(i,list.get(j));
                    list.set(j,tempC);
                }
            }
        }
        return list;
    }
    public HBox createButtons(int amount)
{HBox element=new HBox();
    Button btnz[]=new Button[amount];
    String lbs[]=new String[]{"KeyPad","Reload","Add"};
    for(int i=0;i<amount;i++)
    {
        btnz[i]=new Button(lbs[i]);
        element.setSpacing(20);
        element.getChildren().addAll(btnz[i]);

    }
    btnz[0].setOnAction(e->{

        this.stage.setScene(new KeyPadScene(stage,main_scene).keyPad());
    });
    btnz[1].setOnAction(e->{
        load(stage);
    });
    return element;

}
  
    public VBox createPage(){
        
        VBox box = new VBox(5);
        final String user;
        phonebook.loadPhoneBook();
        ArrayList<Character>charBin=new ArrayList<>();
    

       // int page = pageIndex * pb.size();
        for (Contact c : orderd()) {
            VBox element = new VBox();
            Hyperlink link = new Hyperlink(c.getFirstname()+" "+c.getLastname());
           String s=c.getFirstname().charAt(0)+"";
        
            Label lbl=new Label(s.toUpperCase()); 
          
          
            link.setVisited(false);
            //previousScene=scene;
           // user=pb.get(0).get(i)+" "+pb.get(1).get(i);
            link.setOnAction(new EventHandler<ActionEvent>()
            {
                @Override
             public void handle(ActionEvent e)
             { 
                 stage.setScene(new ProfileSpace(stage,main_scene,c).profileScene());
                /* userClickedOn=link.getText();
                pr.setUser(userClickedOn);
                  textfields[0].setPromptText("First Name..");
         textfields[0].setText(firstname(pr.getUser()));
          textfields[1].setPromptText("Second Name..");
          textfields[1].setText(secondname(pr.getUser()));
                System.out.println(pr);
                window.setScene(profileSpace("User name"));
*/
            }
            });

            link.getStyleClass().add("names");
            VBox tbox=new VBox();
            Separator sep=new Separator();
            sep.setPrefWidth(main_scene.getWidth());
            tbox.getChildren().addAll(lbl,sep);
            tbox.setSpacing(10.0);
            if(!charBin.contains(c.getFirstname().charAt(0)))
           {
               element.getChildren().addAll(tbox,link);
               charBin.add(c.getFirstname().charAt(0));
            }
            else
            element.getChildren().addAll(link);
            //element.setOnMouseEntered(e->System.out.println(link));
            element.getStyleClass().add("contactElement");
            box.getChildren().add(element);
        }
        return box;
    }
    public static void main(String[] args) {
        launch(args);
    }
}